//"Paint" in javafx
//Author: Michael Albers
//Opens .png .jpg and .bmp files and displays them, save displayed image with or without new file path


package org.example.paintfx;


import javafx.geometry.Pos;
import javafx.scene.control.ToolBar;
import javafx.application.Application;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.SnapshotParameters;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.image.PixelReader;
import javafx.scene.image.WritableImage;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Shape;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.FileChooser;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ScrollPane;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Stack;

import javafx.scene.layout.StackPane;

public class PaintApp extends Application {

    private Canvas canvas = new Canvas();                   //canvas that can be drawn on
    private ShapeTool currentTool;

    private ObjectProperty<Color> currentColor = new SimpleObjectProperty<>(Color.BLACK);

    private ObjectProperty<Color> fillColor = new SimpleObjectProperty<>(Color.WHITE);
    private ObjectProperty<Color> borderColor = new SimpleObjectProperty<>(Color.BLACK);
    private double borderWidth = 5;                         //shape border width
    private double dashInterval = borderWidth * 2;

    //will be used for adjusting drawing color
    private boolean drawingEnabled = false;                 //boolean for drawing toggle
    private boolean eraserEnabled = false;                  //eraser tool toggled on or off
    private boolean dashedOutlineEnabled = false;
    private boolean rectangleEnabled = false;
    private boolean squareEnabled = false;
    private boolean circleEnabled = false;

    private boolean triangleEnabled = false;

    private boolean ellipseEnabled = false;
    private double startX, startY;  // Starting point for the line

    private boolean isDrawingSaved = false; // Track if the drawing is saved


    private boolean straightLineEnabled = false;
    private double lineWidth = 5;                               //default drawing thickness
    private double eraserWidth = 10;

    private final ImageView imageView = new ImageView();        //displays images loaded into it in main paint window
    private File currentFile;                                   //for saving loaded file/displayed image to a file
    final GraphicsContext gc = canvas.getGraphicsContext2D();  //interacting with the canvas

    private List<Line> lines = new ArrayList<>();


    StackPane stackPane = new StackPane(imageView, canvas);     //stackpane with imageView as a base and the canvas layered over it

    public static Stack canvasStack = new Stack();      //Used for the undo feature
    public static Stack redoStack = new Stack();        //Used for the redo feature

    @Override
    public void start(Stage primaryStage) {

        ////////////////////////////////////////////////////////////////////////
        //add blank image for default imageview
        Image blankCanvas = new WritableImage(1000, 600);
        imageView.setImage(blankCanvas);

        //adjusts canvas to match imageview dimensions
        Image image = imageView.getImage();
        canvas.setWidth(image.getWidth());
        canvas.setHeight(image.getHeight());


        //makes the canvas drawable
        //initDraw(graphicsContext);


        // Create MenuBar
        MenuBar menuBar = new MenuBar();

        //adds menu dropdowns to menubar, see functions themselves for more details
        addFileMenu(primaryStage, menuBar);
        addEditMenu(primaryStage, menuBar);
        addHelpMenu(menuBar, primaryStage);

        //scroll pane for traversing large images
        ScrollPane scrollPane = new ScrollPane();
        scrollPane.setContent(stackPane);




        ToggleButton rectButton = new ToggleButton("Rectangle");
        ToggleButton circleButton = new ToggleButton("Circle");

        ShapeTool rectangleTool = new RectangleTool(gc, rectButton);
        // Set up button actions to switch tools
        rectButton.setOnAction(e -> currentTool = rectangleTool);



        canvas.setOnMousePressed(event -> {
            if (currentTool != null) {
                currentTool.onMousePressed(event);
            }
        });

        canvas.setOnMouseDragged(event -> {
            if (currentTool != null) {
                currentTool.onMouseDragged(event, fillColor.getValue(), borderColor.getValue(), borderWidth);
            }
        });

        canvas.setOnMouseReleased(event -> {
            if (currentTool != null) {
                currentTool.onMouseReleased(event, fillColor.getValue(), borderColor.getValue(), borderWidth);
            }
        });

        //tool bar for drawing tools
        ToolBar toolBar1 = new ToolBar(
            createDrawButton(),                 //draw toggle
            createLineColorPicker(),                         //color chooser
            createLineWidthSlider(),           //width slider
            createStraightLineButton(),
            createEraser(),
            createEraserWidthSlider()
        );

        ToolBar toolBar2 = new ToolBar(
                createBorderSlider(),
                createBorderColorPicker(),
                createFillColorPicker(),
                createDashedToggleButton(),
                createRectangleButton(),
                createSquareButton(),
                createCircleButton(),
                createTriangleButton(),
                createEllipseButton(),
                rectButton

        );


        // Add MenuBar and scrollpane to gridpane
        GridPane gridPane = new GridPane();
        gridPane.add(menuBar,0,0);
        gridPane.add(toolBar1, 0 ,1);
        gridPane.add(toolBar2, 0 ,2);
        gridPane.add(scrollPane, 0, 3);

        // Scene setup
        Scene scene = new Scene(gridPane, 800, 600);
        primaryStage.setTitle("PaintFX");
        primaryStage.setScene(scene);


        //CTRL + S to save as
        scene.getAccelerators().put(
                new KeyCodeCombination(KeyCode.S, KeyCombination.CONTROL_DOWN),
                () -> saveImageAs(primaryStage) // The method you want to run when the shortcut is pressed
        );

        //CTRL + H to show "help"
        scene.getAccelerators().put(
                new KeyCodeCombination(KeyCode.H, KeyCombination.CONTROL_DOWN),
                this::showHelp
        );

        //CTRL + A to show "about"
        scene.getAccelerators().put(
                new KeyCodeCombination(KeyCode.A, KeyCombination.CONTROL_DOWN),
                () -> showAbout(primaryStage)
        );

        //window popup before closing
        primaryStage.setOnCloseRequest(event -> {
            event.consume(); // Consume the close event to prevent the window from closing immediately
            handleWindowClose(primaryStage);
        });

        primaryStage.show();
    }


    //open image from chosen file path
    private void openImage(Stage stage) {
        //opens file browser
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.bmp"));
        File file = fileChooser.showOpenDialog(stage);

        //opens image if it has a valid file extension
        if (file != null) {
            try {
                Image image = new Image(new FileInputStream(file));
                imageView.setImage(image);
                canvas.setHeight(image.getHeight());
                canvas.setWidth(image.getWidth());
                currentFile = file;
                //clears any drawings when opening a new image
                gc.clearRect(0, 0 , canvas.getWidth(), canvas.getHeight());
            } catch (IOException ex) {
                errorPopup("Could not open image file.");
            }
        }
    }

    //used for displaying an error message(mostly invalid file formats)
    private void errorPopup(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    //saves opened image to its SAME filepath with SAME name and SAME extension
    private void saveImage() {
        if (currentFile != null) {
            try {
                saveImageToFile(currentFile);
            } catch (IOException ex) {
                errorPopup("Could not save image file.");
            }
        } else {
            errorPopup("No file to save. Use 'Save As...' instead.");
        }
    }

    //choose a filepath, name, and extension(can convert bmp/jpg/png interchangeably)
    private void saveImageAs(Stage stage) {
        //image displayed in paint
        if (imageView.getImage() != null) {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Save Image");

            //3 possible file extensions: .png .jpg and .bmp
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG files (*.png)", "*.png"));
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("JPG files (*.jpg)", "*.jpg"));
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("BMP files (*.bmp)", "*.bmp"));
            File file = fileChooser.showSaveDialog(stage);
            if (file != null) {
                try {
                    saveImageToFile(file);
                    currentFile = file; // Updates currentFile to the new file path
                } catch (IOException ex) {
                    errorPopup("Could not save image file.");
                }
            }
        } else {
            errorPopup("No image to save.");
        }
    }



    //saves image to specified file path
    private void saveImageToFile(File file) throws IOException {
        // Capture the snapshot of the StackPane
        WritableImage writableImage = new WritableImage((int) stackPane.getWidth(), (int) stackPane.getHeight());
        SnapshotParameters params = new SnapshotParameters();
        params.setFill(Color.TRANSPARENT); // To preserve transparency, if needed
        stackPane.snapshot(params, writableImage);

        // Convert WritableImage to BufferedImage (without SwingFXUtils)
        int width = (int) writableImage.getWidth();
        int height = (int) writableImage.getHeight();

        String formatName = getFileExtension(file.getName());

        // Determine if image needs to support transparency (ARGB) or not (RGB)
        int bufferedImageType;
        if (formatName.equals("png")) {
            bufferedImageType = BufferedImage.TYPE_INT_ARGB;
        } else {
            bufferedImageType = BufferedImage.TYPE_INT_RGB;
        }

        // Create a BufferedImage to hold the pixels from the WritableImage
        BufferedImage bufferedImage = new BufferedImage(width, height, bufferedImageType);

        // Extract pixel data from WritableImage
        PixelReader pixelReader = writableImage.getPixelReader();

        // Write each pixel to the BufferedImage
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                Color color = pixelReader.getColor(x, y);
                // If the pixel is fully transparent, make it white
                if (color.getOpacity() == 0) {
                    int whiteRGB = 0xFFFFFFFF; // White with no transparency (opaque white)
                    bufferedImage.setRGB(x, y, whiteRGB);
                } else {
                    // Convert the color to ARGB (preserve the original pixel)
                    int argb = (int) (color.getOpacity() * 255) << 24 |
                            (int) (color.getRed() * 255) << 16 |
                            (int) (color.getGreen() * 255) << 8 |
                            (int) (color.getBlue() * 255);

                    // For non-ARGB formats (like JPG, BMP), ignore transparency
                    if (bufferedImageType == BufferedImage.TYPE_INT_RGB) {
                        argb = argb | 0xFF000000; // Make it fully opaque
                    }

                    bufferedImage.setRGB(x, y, argb);
            }}
        }

        // Save the BufferedImage to file using ImageIO
        if (!ImageIO.write(bufferedImage, formatName, file)) {
            throw new IOException("Could not save the image in " + formatName + " format.");
        }
    }


    //gets the format of an image from its extension (.png, .jpg, .bmp)
    private String getFileExtension(String fileName) {
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1).toLowerCase();
    }



    //adds "File" dropdown menu to a menuBar, takes primaryStage as an argument so functions can interact with images on the stage
    private void addFileMenu(Stage primaryStage, MenuBar menuBar){
        // Create File menu
        Menu fileMenu = new Menu("File");
        // Create MenuItems
        MenuItem openMenuItem = new MenuItem("Open Image");
        MenuItem saveMenuItem = new MenuItem("Save Image");
        MenuItem saveAsMenuItem = new MenuItem("Save As...");
        // Add MenuItems to File menu
        fileMenu.getItems().addAll(openMenuItem, saveMenuItem, saveAsMenuItem);
        // Add File menu to MenuBar
        menuBar.getMenus().add(fileMenu);

        // Set actions for the MenuItems
        openMenuItem.setOnAction(e -> openImage(primaryStage));
        saveMenuItem.setOnAction(e -> saveImage());
        saveAsMenuItem.setOnAction(e -> saveImageAs(primaryStage));
    }

    //help options displayed on top menu as drop-down options
    private void addHelpMenu(MenuBar menuBar, Stage primaryStage){
        //Help Menu drop down
        Menu helpMenu = new Menu("Help");

        //Help items
        MenuItem helpTab = new MenuItem("Help");
        MenuItem aboutTab = new MenuItem("About");

        helpMenu.getItems().addAll(helpTab, aboutTab);

        menuBar.getMenus().add(helpMenu);

        //open google or something idk
        helpTab.setOnAction(e -> showHelp());
        aboutTab.setOnAction(e -> showAbout(primaryStage));

    }

    private void addEditMenu(Stage primaryStage, MenuBar menuBar){
        Menu editMenu = new Menu("Edit");

        MenuItem adjustCanvas = new MenuItem("Adjust Canvas");

        editMenu.getItems().addAll(adjustCanvas);

        menuBar.getMenus().add(editMenu);

        editMenu.setOnAction((e -> {
            showCanvasDimensions();
        }));
    }

    private void showCanvasDimensions(){
        // Create a new stage for the popup
        Stage popupStage = new Stage();
        popupStage.setTitle("Adjust Canvas Size");

        // Block input events to other windows while this one is open
        popupStage.initModality(Modality.APPLICATION_MODAL);

        // Create a GridPane layout for the inputs
        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10));
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setAlignment(Pos.CENTER);

        // Label and TextField for Width
        Label widthLabel = new Label("New Width:");
        TextField widthField = new TextField();
        widthField.setPromptText("Enter width");

        // Label and TextField for Height
        Label heightLabel = new Label("New Height:");
        TextField heightField = new TextField();
        heightField.setPromptText("Enter height");

        // Add the inputs to the gridPane
        gridPane.add(widthLabel, 0, 0);
        gridPane.add(widthField, 1, 0);
        gridPane.add(heightLabel, 0, 1);
        gridPane.add(heightField, 1, 1);

        // Apply Button
        Button applyButton = new Button("Apply");
        applyButton.setOnAction(event -> {
            try {
                // Get the new dimensions
                double newWidth = Double.parseDouble(widthField.getText());
                double newHeight = Double.parseDouble(heightField.getText());

                // Resize the canvas
                canvas.setWidth(newWidth);
                canvas.setHeight(newHeight);
                imageView.setFitWidth(newWidth);
                imageView.setFitHeight(newHeight);
                stackPane.setMaxWidth(newWidth);
                stackPane.setMaxHeight(newHeight);

                // Clear or the canvas after resizing
                //canvas.getGraphicsContext2D().clearRect(0, 0, newWidth, newHeight);

                // Close the popup window after applying the changes
                popupStage.close();
            } catch (NumberFormatException e) {
                System.out.println("Invalid dimensions entered. Please enter valid numbers.");
            }
        });

        // Add the button to the layout
        gridPane.add(applyButton, 1, 2);

        // Set up the scene and show the popup
        Scene popupScene = new Scene(gridPane, 300, 200);
        popupStage.setScene(popupScene);
        popupStage.showAndWait(); // Block until the window is closed
    }

    //pop up window with some tips on how to use the software
    private void showHelp() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Help");
        alert.setHeaderText(null);
        alert.setContentText("This is a basic image editor. You can open, edit, and save images.\n" +
                "Use the 'Draw Line' option to draw on the image and 'Line Properties' to select drawing color or thickness.");
        alert.showAndWait();
    }

    //pop up window with information about the softwar
    private void showAbout(Stage primaryStage) {
        Stage aboutStage = new Stage();
        aboutStage.setTitle("About");

        Label aboutLabel = new Label("Image Editor Application\nVersion 1.0\nLast updated 9/6/2024");
        aboutLabel.setPadding(new Insets(10));
        VBox vbox = new VBox(aboutLabel);
        vbox.setPadding(new Insets(10));

        Scene aboutScene = new Scene(vbox, 200, 100);
        aboutStage.setScene(aboutScene);
        aboutStage.initOwner(primaryStage);
        aboutStage.show();
    }

    //draw button
    private ToggleButton createDrawButton(){
        //toggle button for drawing a line
        ToggleButton drawToggle = new ToggleButton("Draw Line");
        drawToggle.setOnAction(event -> drawingEnabled = drawToggle.isSelected());

        // Add mouse event handlers to the canvas
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (drawingEnabled) {
                gc.setLineWidth(lineWidth);
                gc.beginPath();
                gc.moveTo(event.getX(), event.getY());
                gc.stroke();
                gc.setStroke(currentColor.getValue());
            }
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (drawingEnabled) {
                gc.lineTo(event.getX(), event.getY());
                gc.stroke();
                gc.setStroke(currentColor.getValue());
            }
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (drawingEnabled) {
                gc.closePath(); // Optional: closes the path if needed
            }
        });


        return drawToggle;
    }

    private ToggleButton createEraser(){
        //toggle button for drawing a line
        ToggleButton eraser = new ToggleButton("Eraser");
        eraser.setOnAction(event -> eraserEnabled = eraser.isSelected());

        // Add mouse event handlers to the canvas
        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (eraserEnabled) {
                gc.setLineWidth(eraserWidth);
                gc.beginPath();
                gc.moveTo(event.getX(), event.getY());
                gc.stroke();
                gc.setStroke(Color.WHITE);
            }
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (eraserEnabled) {
                gc.lineTo(event.getX(), event.getY());
                gc.stroke();
                gc.setStroke(Color.WHITE);
            }
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (eraserEnabled) {
                gc.closePath(); // Optional: closes the path if needed
            }
        });

        return eraser;
    }

    private ToggleButton createStraightLineButton() {
        ToggleButton straightLine = new ToggleButton("Draw straight line");
        straightLine.setOnAction(event -> straightLineEnabled = straightLine.isSelected());


        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!straightLineEnabled) return;  // Only allow drawing if the button is active
            gc.setLineWidth(lineWidth);
            // Set the starting point for the line
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!straightLineEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the line started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);
            // Draw the temporary line from start to the current mouse position
            gc.setStroke(currentColor.getValue());
            gc.strokeLine(startX, startY, event.getX(), event.getY());
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!straightLineEnabled) return;  // Only allow drawing if the button is active
            // Finalize the line when the mouse is released
            gc.setStroke(currentColor.getValue());
            gc.strokeLine(startX, startY, event.getX(), event.getY());
        });

        return straightLine;
    }

    private ToggleButton createRectangleButton() {
        ToggleButton rectangleButton = new ToggleButton("Draw Rectangle");
        rectangleButton.setOnAction(event -> rectangleEnabled = rectangleButton.isSelected());
        gc.setLineWidth(borderWidth);  // Set initial border width

        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!rectangleEnabled) return;  // Only allow drawing if the button is active

            // Set the starting point for the rectangle
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!rectangleEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the rectangle started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);

            // Calculate the width and height based on the mouse's current position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Calculate the top-left corner depending on the drag direction
            double rectX = Math.min(startX, currentX);
            double rectY = Math.min(startY, currentY);

            // Draw the filled rectangle
            gc.setFill(fillColor.getValue());  // Use the selected fill color
            gc.fillRect(rectX, rectY, width, height);

            // Draw the rectangle border
            gc.setStroke(borderColor.getValue());  // Use the selected border color
            gc.setLineWidth(borderWidth);  // Use the selected border width
            gc.strokeRect(rectX, rectY, width, height);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!rectangleEnabled) return;  // Only allow drawing if the button is active

            // Calculate the width and height based on the mouse's current position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Calculate the top-left corner depending on the drag direction
            double rectX = Math.min(startX, currentX);
            double rectY = Math.min(startY, currentY);

            // Draw the filled rectangle
            gc.setFill(fillColor.getValue());
            gc.fillRect(rectX, rectY, width, height);


            // Draw the rectangle border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokeRect(rectX, rectY, width, height);
        });

        return rectangleButton;
    }

    private ToggleButton createSquareButton() {
        ToggleButton squareButton = new ToggleButton("Draw Square");
        squareButton.setOnAction(event -> squareEnabled = squareButton.isSelected());
        gc.setLineWidth(borderWidth);  // Set initial border width

        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!squareEnabled) return;  // Only allow drawing if the button is active

            // Set the starting point for the square
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!squareEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the square started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Use the smaller of the two to ensure a perfect square
            double size = Math.min(width, height);

            // Calculate the top-left corner based on the drag direction
            double squareX = startX < currentX ? startX : startX - size;
            double squareY = startY < currentY ? startY : startY - size;

            // Draw the filled square
            gc.setFill(fillColor.getValue());  // Use the selected fill color
            gc.fillRect(squareX, squareY, size, size);


            // Draw the square border
            gc.setStroke(borderColor.getValue());  // Use the selected border color
            gc.setLineWidth(borderWidth);  // Use the selected border width
            gc.strokeRect(squareX, squareY, size, size);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!squareEnabled) return;  // Only allow drawing if the button is active

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Use the smaller of the two to ensure a perfect square
            double size = Math.min(width, height);

            // Calculate the top-left corner based on the drag direction
            double squareX = startX < currentX ? startX : startX - size;
            double squareY = startY < currentY ? startY : startY - size;

            // Draw the filled square
            gc.setFill(fillColor.getValue());
            gc.fillRect(squareX, squareY, size, size);


            // Draw the square border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokeRect(squareX, squareY, size, size);
        });

        return squareButton;
    }


    private ToggleButton createCircleButton() {
        ToggleButton circleButton = new ToggleButton("Draw Circle");
        circleButton.setOnAction(event -> circleEnabled = circleButton.isSelected());
        gc.setLineWidth(borderWidth);  // Set initial border width

        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!circleEnabled) return;  // Only allow drawing if the button is active

            // Set the starting point for the circle
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!circleEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the circle started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Use the smaller of the two to ensure a perfect circle
            double diameter = Math.min(width, height);

            // Calculate the top-left corner based on the drag direction
            double circleX = Math.min(startX, currentX);
            double circleY = Math.min(startY, currentY);

            // Adjust the corner so the circle is centered on the drag point
            if (currentX < startX) circleX = startX - diameter;
            if (currentY < startY) circleY = startY - diameter;

            // Draw the filled circle
            gc.setFill(fillColor.getValue());  // Use the selected fill color
            gc.fillOval(circleX, circleY, diameter, diameter);



            // Draw the circle border
            gc.setStroke(borderColor.getValue());  // Use the selected border color
            gc.setLineWidth(borderWidth);  // Use the selected border width
            gc.strokeOval(circleX, circleY, diameter, diameter);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!circleEnabled) return;  // Only allow drawing if the button is active

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Use the smaller of the two to ensure a perfect circle
            double diameter = Math.min(width, height);

            // Calculate the top-left corner based on the drag direction
            double circleX = Math.min(startX, currentX);
            double circleY = Math.min(startY, currentY);

            // Adjust the corner so the circle is centered on the drag point
            if (currentX < startX) circleX = startX - diameter;
            if (currentY < startY) circleY = startY - diameter;

            // Draw the filled circle
            gc.setFill(fillColor.getValue());
            gc.fillOval(circleX, circleY, diameter, diameter);


            // Draw the circle border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokeOval(circleX, circleY, diameter, diameter);
        });

        return circleButton;
    }


    private ToggleButton createTriangleButton() {
        ToggleButton triangleButton = new ToggleButton("Draw Triangle");
        triangleButton.setOnAction(event -> triangleEnabled = triangleButton.isSelected());
        gc.setLineWidth(borderWidth);  // Set initial border width

        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!triangleEnabled) return;  // Only allow drawing if the button is active

            // Set the starting point for the triangle
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!triangleEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the triangle started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);

            // Calculate the base and height of the triangle based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();

            // Base vertices
            double baseX1 = startX;
            double baseY1 = startY;
            double baseX2 = currentX;
            double baseY2 = startY;  // Keep the base horizontal along the y-axis of startY

            // Calculate the top vertex (midpoint of the base and height)
            double topX = (baseX1 + baseX2) / 2;  // Midpoint of the base
            double topY = currentY;  // Height is the vertical distance from startY to currentY

            // Draw the filled triangle
            gc.setFill(fillColor.getValue());
            gc.fillPolygon(new double[]{baseX1, baseX2, topX}, new double[]{baseY1, baseY2, topY}, 3);

            // Set dashed or solid outline


            // Draw the triangle border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokePolygon(new double[]{baseX1, baseX2, topX}, new double[]{baseY1, baseY2, topY}, 3);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!triangleEnabled) return;  // Only allow drawing if the button is active

            // Calculate the base and height of the triangle based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();

            // Base vertices
            double baseX1 = startX;
            double baseY1 = startY;
            double baseX2 = currentX;
            double baseY2 = startY;

            // Calculate the top vertex (midpoint of the base and height)
            double topX = (baseX1 + baseX2) / 2;  // Midpoint of the base
            double topY = currentY;

            // Draw the filled triangle
            gc.setFill(fillColor.getValue());
            gc.fillPolygon(new double[]{baseX1, baseX2, topX}, new double[]{baseY1, baseY2, topY}, 3);

            // Set dashed or solid outline

            // Draw the triangle border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokePolygon(new double[]{baseX1, baseX2, topX}, new double[]{baseY1, baseY2, topY}, 3);
        });

        return triangleButton;
    }

    private ToggleButton createEllipseButton() {
        ToggleButton ellipseButton = new ToggleButton("Draw Ellipse");
        ellipseButton.setOnAction(event -> ellipseEnabled = ellipseButton.isSelected());
        gc.setLineWidth(borderWidth);  // Set initial border width

        // Store the canvas state when the mouse is pressed
        WritableImage canvasSnapshot = new WritableImage((int) canvas.getWidth(), (int) canvas.getHeight());

        canvas.addEventHandler(MouseEvent.MOUSE_PRESSED, event -> {
            if (!ellipseEnabled) return;  // Only allow drawing if the button is active

            // Set the starting point for the ellipse
            startX = event.getX();
            startY = event.getY();

            // Take a snapshot of the current canvas content
            canvas.snapshot(null, canvasSnapshot);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_DRAGGED, event -> {
            if (!ellipseEnabled) return;  // Only allow drawing if the button is active

            // Restore the canvas to its state before the ellipse started being drawn
            gc.drawImage(canvasSnapshot, 0, 0);

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Calculate the top-left corner based on the drag direction
            double ellipseX = startX < currentX ? startX : startX - width;
            double ellipseY = startY < currentY ? startY : startY - height;

            // Draw the filled ellipse
            gc.setFill(fillColor.getValue());  // Use the selected fill color
            gc.fillOval(ellipseX, ellipseY, width, height);


            // Draw the ellipse border
            gc.setStroke(borderColor.getValue());  // Use the selected border color
            gc.setLineWidth(borderWidth);  // Use the selected border width
            gc.strokeOval(ellipseX, ellipseY, width, height);
        });

        canvas.addEventHandler(MouseEvent.MOUSE_RELEASED, event -> {
            if (!ellipseEnabled) return;  // Only allow drawing if the button is active

            // Calculate the width and height based on the current mouse position
            double currentX = event.getX();
            double currentY = event.getY();
            double width = Math.abs(currentX - startX);
            double height = Math.abs(currentY - startY);

            // Calculate the top-left corner based on the drag direction
            double ellipseX = startX < currentX ? startX : startX - width;
            double ellipseY = startY < currentY ? startY : startY - height;

            // Draw the filled ellipse
            gc.setFill(fillColor.getValue());
            gc.fillOval(ellipseX, ellipseY, width, height);



            // Draw the ellipse border
            gc.setStroke(borderColor.getValue());
            gc.setLineWidth(borderWidth);
            gc.strokeOval(ellipseX, ellipseY, width, height);
        });

        return ellipseButton;
    }
    private VBox createLineWidthSlider(){
        //line width slider
        Slider lineWidthSlider = new Slider(1, 10, 5); // Min=1, Max=10, Initial=5
        lineWidthSlider.setShowTickMarks(true);
        lineWidthSlider.setShowTickLabels(true);
        lineWidthSlider.setMajorTickUnit(1);
        lineWidthSlider.setBlockIncrement(1);
        lineWidthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            lineWidth = newVal.doubleValue(); // Update line width based on slider value
            gc.setLineWidth(lineWidth); // Set new line width
        });

        //label for width slider
        Label sliderText = new Label("Line Width:");
        return new VBox(sliderText, lineWidthSlider);
    }

    private VBox createEraserWidthSlider(){
        //line width slider
        Slider eraserWidthSlider = new Slider(10, 50, 10); // Min=1, Max=20, Initial=5
        eraserWidthSlider.setShowTickMarks(true);
        eraserWidthSlider.setShowTickLabels(true);
        eraserWidthSlider.setMajorTickUnit(5);
        eraserWidthSlider.setBlockIncrement(5);
        eraserWidthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            eraserWidth = newVal.doubleValue(); // Update eraser width based on slider value
            gc.setLineWidth(eraserWidth); // Set new line width
        });

        //label for width slider
        Label sliderText = new Label("Eraser Width:");
        return new VBox(sliderText, eraserWidthSlider);
    }

    private VBox createLineColorPicker(){
        ColorPicker lineColorPicker = new ColorPicker(currentColor.getValue());
        lineColorPicker.setOnAction(e -> {
            currentColor.set(lineColorPicker.getValue());  // Update global variable
        });

        //label for width slider
        Label sliderText = new Label("Line Color:");
        return new VBox(sliderText, lineColorPicker);
    }

    private VBox createBorderColorPicker(){
        ColorPicker bordertColorPicker = new ColorPicker(borderColor.getValue());
        bordertColorPicker.setOnAction(e -> {
            borderColor.set(bordertColorPicker.getValue());  // Update global variable
        });

        //label for width slider
        Label sliderText = new Label("Shape Border Color:");
        return new VBox(sliderText, bordertColorPicker);
    }

    private ToggleButton createDashedToggleButton() {
        ToggleButton dashedToggleButton = new ToggleButton("Dashed Outline");
        dashedToggleButton.setOnAction(event -> {
            if (dashedToggleButton.isSelected()) {
                gc.setLineDashes(dashInterval);  // Set dash length (you can adjust this)
            } else {
                gc.setLineDashes(null);  // Reset to solid line
            }
        });

        return dashedToggleButton;
    }

    private VBox createFillColorPicker(){
        ColorPicker fillColorPicker = new ColorPicker(fillColor.getValue());
        fillColorPicker.setOnAction(e -> {
            fillColor.set(fillColorPicker.getValue());  // Update global variable
        });
        //label for width slider
        Label sliderText = new Label("Shape Fill Color:");
        return new VBox(sliderText, fillColorPicker);
    }



    private VBox createBorderSlider(){
        //line width slider
        Slider lineWidthSlider = new Slider(1, 10, 5); // Min=1, Max=10, Initial=1
        lineWidthSlider.setShowTickMarks(true);
        lineWidthSlider.setShowTickLabels(true);
        lineWidthSlider.setMajorTickUnit(1);
        lineWidthSlider.setBlockIncrement(1);
        lineWidthSlider.valueProperty().addListener((obs, oldVal, newVal) -> {
            borderWidth = newVal.doubleValue(); // Update line width based on slider value
            gc.setLineWidth(borderWidth); // Set new border width
            dashInterval = borderWidth * 2;
        });

        //label for width slider
        Label sliderText = new Label("Shape Border Width:");
        return new VBox(sliderText, lineWidthSlider);
    }

    private void handleWindowClose(Stage stage) {
        if (!isDrawingSaved) {
            // Show confirmation dialog to ask the user if they want to save
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Unsaved Drawing");
            alert.setHeaderText("Your drawing is unsaved.");
            alert.setContentText("Do you want to save your drawing before closing?");

            ButtonType saveButton = new ButtonType("Save");
            ButtonType dontSaveButton = new ButtonType("Don't Save");
            ButtonType cancelButton = new ButtonType("Cancel");

            alert.getButtonTypes().setAll(saveButton, dontSaveButton, cancelButton);

            // Capture user choice
            Optional<ButtonType> result = alert.showAndWait();
            if (result.isPresent() && result.get() == saveButton) {
                saveImageAs(stage);
                stage.close(); // Close the window after saving
            } else if (result.isPresent() && result.get() == dontSaveButton) {
                stage.close(); // Close the window without saving
            }
            // If the user presses "Cancel", do nothing (the window stays open)
        } else {
            stage.close(); // If the drawing is already saved, just close the window
        }
    }

    //good ol main, not much to see here
    public static void main(String[] args) {
        launch(args);
    }
}
